import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:seshlly/features/auth/domain/usecases/onboarding_competed.dart';
import 'package:seshlly/features/dashboard/challanges/data/datasource/challenge_remote_datasource.dart';
import 'package:seshlly/features/dashboard/challanges/data/repositories/challenge_repository.dart';
import 'package:seshlly/features/dashboard/challanges/data/repositories/challenge_repository_impl.dart';
import 'package:seshlly/features/dashboard/challanges/presentation/bloc/challenge_bloc.dart';
import 'package:seshlly/features/dashboard/chat/data/datasource/chat_remote_datasource.dart';
import 'package:seshlly/features/dashboard/chat/data/repositories/chat_repository.dart';
import 'package:seshlly/features/dashboard/chat/data/repositories/chat_repository_impl.dart';
import 'package:seshlly/features/dashboard/chat/presentation/bloc/chat_bloc.dart';
import 'package:seshlly/features/dashboard/session/data/datasource/session_remote_datasource.dart';
import 'package:seshlly/features/dashboard/session/data/repositories/session_repository.dart';
import 'package:seshlly/features/dashboard/session/data/repositories_impl/session_repository_impl.dart';
import 'package:seshlly/features/dashboard/session/presentation/bloc/session_bloc.dart';
import 'package:seshlly/features/notification/data/datasource/notification_remote_datasource.dart';
import 'package:seshlly/features/notification/data/repositories/notification_repositorie.dart';
import 'package:seshlly/features/notification/data/repositories_impl/notification_repositories_impl.dart';
import 'package:seshlly/features/notification/presentation/bloc/notification_bloc.dart';
import 'package:seshlly/features/strike/data/datasource/strike_remote_datasource.dart';
import 'package:seshlly/features/strike/data/repositories/strike_repository.dart';
import 'package:seshlly/features/subscription/data/datasource/subscription_remote_datasource.dart';
import 'package:seshlly/features/subscription/data/repositories/subscription_repository.dart';
import 'package:seshlly/features/subscription/presentation/bloc/subscription_bloc.dart';

import '../core/api/dio_client.dart';
import '../core/network/connectivity_service.dart';
import '../core/services/secure_storage_service.dart';
import '../core/services/storage_service.dart';
import '../features/auth/data/datasource/auth_remote_datasource.dart';
import '../features/auth/data/repository_impl/auth_repository_impl.dart';
import '../features/auth/domain/repositories/auth_repository.dart';
import '../features/auth/domain/usecases/login_usecase.dart';
import '../features/auth/domain/usecases/logout_usecase.dart';
import '../features/auth/domain/usecases/register_usecase.dart';
import '../features/auth/presentation/bloc/auth_bloc.dart';
import '../features/dashboard/chat/presentation/bloc/match_request_bloc.dart';
import '../features/dashboard/chat/presentation/bloc/strike_bloc.dart';
import '../features/dashboard/discover/data/datasource/discover_remote_datasource.dart';
import '../features/dashboard/discover/data/repositories/discover_repository.dart';
import '../features/dashboard/discover/data/repository_impl/discover_repository_impl.dart';
import '../features/dashboard/discover/presentation/bloc/discover_bloc.dart';
import '../features/dashboard/profile/data/datasource/profile_remote_datasource.dart';
import '../features/dashboard/profile/data/repository_impl/profile_repository_impl.dart';
import '../features/dashboard/profile/domain/repositories/profile_repository.dart';
import '../features/dashboard/profile/domain/usecases/update_profile_usecase.dart';
import '../features/dashboard/profile/presentation/bloc/profile_bloc.dart';
import '../features/strike/data/repositories/strike_repository_impl.dart';
import '../features/subscription/data/repositories/subscription_repositories_impl.dart';

final getIt = GetIt.instance;

Future<void> setupDependencies() async {
  /// CORE

  getIt.registerLazySingleton<Dio>(() => Dio());

  getIt.registerLazySingleton<SecureStorageService>(
    () => SecureStorageService(),
  );
  getIt.registerLazySingleton<StorageService>(() => StorageService());

  getIt.registerLazySingleton<ConnectivityService>(() => ConnectivityService());
  getIt.registerLazySingleton<DioClient>(() => DioClient(getIt()));

  /// AUTH
  getIt.registerLazySingleton<AuthRemoteDataSource>(
    () => AuthRemoteDataSource(getIt()),
  );
  getIt.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(getIt(), getIt(), getIt()),
  );
  getIt.registerLazySingleton(() => LoginUseCase(getIt(), getIt(), getIt()));
  getIt.registerLazySingleton(() => RegisterUseCase(getIt()));
  getIt.registerLazySingleton(() => OnboardingCompeted(getIt()));
  getIt.registerLazySingleton<AuthBloc>(
    () => AuthBloc(getIt(), getIt(), getIt(), getIt(), getIt(), getIt()),
  );

  /// Profile
  getIt.registerLazySingleton<ProfileRemoteDatasource>(
    () => ProfileRemoteDatasource(getIt()),
  );
  getIt.registerLazySingleton<ProfileRepository>(
    () => ProfileRepositoryImpl(getIt(), getIt(), getIt()),
  );

  getIt.registerFactory<ProfileBloc>(
    () => ProfileBloc(getIt(), getIt(), getIt(), getIt()),
  );
  getIt.registerLazySingleton(() => UpdateProfileUseCase(getIt()));
  getIt.registerLazySingleton(() => OnloadProfileUseCase(getIt()));
  getIt.registerLazySingleton(() => LogoutUseCase(getIt()));
  getIt.registerLazySingleton(() => GetBuddyProfileUseCase(getIt()));
  getIt.registerLazySingleton(() => UpdateProfileAvatarUseCase(getIt()));

  /// Discover
  getIt.registerLazySingleton<DiscoverRemoteDatasource>(
    () => DiscoverRemoteDatasource(getIt()),
  );
  getIt.registerLazySingleton<DiscoverRepository>(
    () => DiscoverRepositoryImpl(getIt(), getIt(), getIt()),
  );

  getIt.registerFactory<DiscoverBloc>(
    () => DiscoverBloc(discoverRepository: getIt()),
  );

  ///Session
  getIt.registerLazySingleton<SessionRemoteDatasource>(
    () => SessionRemoteDatasource(getIt()),
  );
  getIt.registerLazySingleton<SessionRepository>(
    () => SessionRepositoryImpl(getIt(), getIt(), getIt()),
  );
  getIt.registerFactory<SessionBloc>(
    () => SessionBloc(sessionRepository: getIt()),
  );

  ///Notifications
  getIt.registerLazySingleton<NotificationRemoteDataSource>(
    () => NotificationRemoteDataSource(getIt()),
  );
  getIt.registerLazySingleton<NotificationRepository>(
    () => NotificationRepositoryImpl(getIt(), getIt()),
  );
  getIt.registerFactory<NotificationBloc>(
    () => NotificationBloc(notificationRepository: getIt()),
  );

  ///Subscription
  getIt.registerLazySingleton<SubscriptionRemoteDataSource>(
    () => SubscriptionRemoteDataSource(getIt()),
  );
  getIt.registerLazySingleton<SubscriptionRepository>(
    () => SubscriptionRepositoriesImpl(getIt(), getIt()),
  );
  getIt.registerFactory<SubscriptionBloc>(
    () => SubscriptionBloc(subscriptionRepository: getIt()),
  );

  ///Chat
  getIt.registerLazySingleton<ChatRemoteDatasource>(
    () => ChatRemoteDatasource(getIt()),
  );
  getIt.registerLazySingleton<ChatRepository>(
    () => ChatRepositoryImpl(getIt(), getIt()),
  );
  getIt.registerFactory<ChatBloc>(() => ChatBloc(chatRepository: getIt()));

  ///Challenges
  getIt.registerLazySingleton<ChallengeRemoteDatasource>(
    () => ChallengeRemoteDatasource(getIt()),
  );
  getIt.registerLazySingleton<ChallengeRepository>(
    () => ChallengeRepositoryImpl(getIt(), getIt()),
  );
  getIt.registerFactory<ChallengeBloc>(
    () => ChallengeBloc(challengeRepository: getIt()),
  );


  //Strike
  getIt.registerLazySingleton<StrikeRemoteDatasource>(
        () => StrikeRemoteDatasource(getIt()),
  );
  getIt.registerLazySingleton<StrikeRepository>(
        () => StrikeRepositoryImpl(getIt(), getIt()),
  );
  /*getIt.registerFactory<ChallengeBloc>(
        () => ChallengeBloc(challengeRepository: getIt()),
  );*/

  getIt.registerFactory<MatchRequestBloc>(
        () => MatchRequestBloc(api: getIt()),
  );

  getIt.registerFactory<StrikeBloc>(
        () => StrikeBloc(api: getIt()),
  );
}

