import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:seshlly/features/dashboard/challanges/presentation/bloc/challenge_bloc.dart';
import 'package:seshlly/features/dashboard/session/presentation/bloc/session_bloc.dart';
import 'package:seshlly/features/dashboard/session/presentation/bloc/session_event.dart';
import 'package:seshlly/routes/app_router.dart';

import '../../core/theme/app_colors.dart';
import '../../di_injection/dependency_injection.dart';
import '../notification/presentation/bloc/notification_bloc.dart';
import 'challanges/presentation/bloc/challenge_event.dart';
import 'chat/presentation/bloc/chat_bloc.dart';
import 'chat/presentation/bloc/match_request_bloc.dart';
import 'chat/presentation/screen/chats_list_screen.dart';
import 'discover/presentation/bloc/discover_bloc.dart';
import 'discover/presentation/bloc/discover_event.dart';
import 'profile/presentation/bloc/profile_bloc.dart';
import 'profile/presentation/bloc/profile_event.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    // Provide feature BLoCs scoped to the shell route lifetime
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (ctx) =>
              getIt<DiscoverBloc>()..add(const DiscoverProfilesLoaded()),
        ),
        MultiBlocProvider(
          providers: [
            BlocProvider<ChatBloc>(
              create: (_) => getIt<ChatBloc>()..add(const ChatListLoaded()),
            ),
            BlocProvider<MatchRequestBloc>(
              create: (_) => getIt<MatchRequestBloc>(),
            ),
          ],
          child: const ChatsListScreen(),
        ),

        BlocProvider(
          create: (ctx) => getIt<SessionBloc>()..add(const SessionsLoaded()),
        ),
        BlocProvider(
          create: (ctx) =>
              getIt<ChallengeBloc>()..add(const ChallengesLoaded()),
        ),
        BlocProvider(
          create: (ctx) => getIt<ProfileBloc>()..add(const ProfileLoaded()),
        ),
      ],
      child: _HomeShell(child: child),
    );
  }
}

class _HomeShell extends StatelessWidget {
  const _HomeShell({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final unread = getIt<NotificationBloc>().state.unreadCount;
    final location = GoRouterState.of(context).uri.toString();

    int currentIndex = 0;
    if (location.startsWith('/chats')) currentIndex = 1;
    if (location.startsWith('/sessions')) currentIndex = 2;
    if (location.startsWith('/challenges')) currentIndex = 3;
    if (location.startsWith('/profile')) currentIndex = 4;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: child,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: BottomNavigationBar(
          currentIndex: currentIndex,
          onTap: (i) {
            switch (i) {
              case 0:
                context.go(AppRoutes.home);
                break;
              case 1:
                context.go(AppRoutes.chats);
                break;
              case 2:
                context.go(AppRoutes.sessions);
                break;
              case 3:
                context.go(AppRoutes.challenges);
                break;
              case 4:
                context.go(AppRoutes.profile);
                break;
            }
          },
          items: [
            const BottomNavigationBarItem(
              icon: Icon(Icons.explore_outlined),
              activeIcon: Icon(Icons.explore),
              label: 'Discover',
            ),
            BottomNavigationBarItem(
              icon: unread > 0
                  ? Badge(
                      label: Text('$unread'),
                      child: const Icon(Icons.chat_bubble_outline),
                    )
                  : const Icon(Icons.chat_bubble_outline),
              activeIcon: const Icon(Icons.chat_bubble),
              label: 'Chats',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.fitness_center_outlined),
              activeIcon: Icon(Icons.fitness_center),
              label: 'Sessions',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.emoji_events_outlined),
              activeIcon: Icon(Icons.emoji_events),
              label: 'Challenges',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}
